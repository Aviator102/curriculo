<?php

class Appointments_model extends CIF_model
{
    public $_table = 'appointments';
    public $_primary_keys = array('appointment_id');
}
