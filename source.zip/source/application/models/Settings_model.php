<?php

class Settings_model extends CIF_model
{
    public $_table = 'settings';
    public $_primary_keys = array('key');


}
