<?php

class Requested_appointments_model extends CIF_model
{
    public $_table = 'requested_appointments';
    public $_primary_keys = array('requested_appointment_id');


}
