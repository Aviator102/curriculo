<?php

class Pricing_plans_model extends CIF_model {

    public $_table = 'pricing_plans';
    public $_primary_keys = array('plan_id');

}
